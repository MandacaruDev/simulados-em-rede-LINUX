//Select2
$.getScript('http://cdnjs.cloudflare.com/ajax/libs/select2/3.4.8/select2.min.js',function(){
           
  /* dropdown and filter select */
  var select = $('#select1').select2();
  var select = $('#select2').select2();
  var select = $('#select3').select2();
  var select = $('#select4').select2();
  var select = $('#select5').select2();
  var select = $('#select6').select2();
  var select = $('#select7').select2();
  var select = $('#select8').select2();
  var select = $('#select9').select2();
  var select = $('#select10').select2();
  var select = $('#select11').select2();
  var select = $('#select12').select2();
  var select = $('#select13').select2();
  var select = $('#select14').select2();
  var select = $('#select15').select2();
  var select = $('#select16').select2();
  var select = $('#select18').select2();
  var select = $('#select19').select2();
  var select = $('#select20').select2();
  var select = $('#select21').select2();
  var select = $('#select22').select2();
  var select = $('#select23').select2();
  var select = $('#select24').select2();
  var select = $('#select25').select2();
  var select = $('#select26').select2();
  var select = $('#select27').select2();
  var select = $('#select28').select2();
  var select = $('#select29').select2();
  var select = $('#select30').select2();
  
  
  
  
  /* Select2 plugin as tagpicker */
  $("#tagPicker").select2({
    closeOnSelect:false
  });

}); //script         
      

$(document).ready(function() {});