<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Pessoa.
 *
 * @author  The scaffold-interface created at 2016-10-28 02:02:11am
 * @link  https://github.com/amranidev/scaffold-interface
 */
class Pessoa extends Model
{
	
	
    protected $table = 'pessoas';

	
}
