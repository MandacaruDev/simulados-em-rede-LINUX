@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Início</div>

                <div class="panel-body">

		<hr>

		<footer>
			<p>&copy; <?php echo date('Y'); ?> SGLAB</p>
		</footer>                </div>
            </div>
        </div>
    </div>
</div>

@endsection
